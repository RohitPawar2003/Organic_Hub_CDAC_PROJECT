package com.cdac.modelmvc;

public enum Role {
ADMIN,FARMER,SHOPKEEPER,CUSTOMER
}

package com.cdac.config;

public class MapperConfig {

}
